-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 02, 2023 at 12:51 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ekspedisi_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `user_id` int(11) NOT NULL,
  `role` varchar(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`user_id`, `role`, `name`, `email`, `password`) VALUES
(1, 'super admin', 'rifqi iqbal pratama', 'rifqi@gmail.com', '03AC674216F3E15C761EE1A5E255F067953623C8B388B4459E13F978D7C846F4'),
(2, 'admin', 'intan', 'intan@gmail.com', '03AC674216F3E15C761EE1A5E255F067953623C8B388B4459E13F978D7C846F4'),
(3, 'admin', 'alwi', 'alwi@gmail.com', '03AC674216F3E15C761EE1A5E255F067953623C8B388B4459E13F978D7C846F4'),
(4, 'admin', 'chandra', 'chandra@gmail.com', '03AC674216F3E15C761EE1A5E255F067953623C8B388B4459E13F978D7C846F4'),
(5, 'admin', 'afri yudha', 'afri@gmail.com', 'A665A45920422F9D417E4867EFDC4FB8A04A1F3FFF1FA07E998E86F7F7A27AE3'),
(6, 'admin', 'iqbal pratama', 'iqbal@gmail.com', '8D969EEF6ECAD3C29A3A629280E686CF0C3F5D5A86AFF3CA12020C923ADC6C92');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ekspedisi`
--

CREATE TABLE `tbl_ekspedisi` (
  `id_ekspedisi` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `nama_pengirim` varchar(255) NOT NULL,
  `email_pengirim` varchar(255) NOT NULL,
  `no_pengirim` varchar(255) NOT NULL,
  `alamat_pengirim` varchar(255) NOT NULL,
  `nama_penerima` varchar(255) NOT NULL,
  `email_penerima` varchar(255) NOT NULL,
  `no_penerima` varchar(255) NOT NULL,
  `alamat_penerima` varchar(255) NOT NULL,
  `nama_barang` varchar(255) NOT NULL,
  `berat_barang` varchar(11) NOT NULL,
  `layanan_antar` varchar(255) NOT NULL,
  `biaya_ekspedisi` varchar(255) NOT NULL,
  `status_pengiriman` varchar(255) NOT NULL,
  `waktu_input` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_ekspedisi`
--

INSERT INTO `tbl_ekspedisi` (`id_ekspedisi`, `user_id`, `nama_pengirim`, `email_pengirim`, `no_pengirim`, `alamat_pengirim`, `nama_penerima`, `email_penerima`, `no_penerima`, `alamat_penerima`, `nama_barang`, `berat_barang`, `layanan_antar`, `biaya_ekspedisi`, `status_pengiriman`, `waktu_input`) VALUES
(1, 2, 'dina', 'dina@gmail.com', '08244541', 'bandung', 'sinta', 'dina@gmail.com', '084844848', 'jakarta', 'baju', '5', 'Sameday', 'Rp35.000', 'Diterima', '2023-01-24 00:53:34'),
(2, 2, 'Roma', 'roma@gmail.com', '0814577554', 'Cimahi', 'Dona', 'roma@gmail.com', '081245487845', 'Bali', 'baju', '5', 'Regular', 'Rp25.000', 'Diterima', '2023-01-24 11:10:10'),
(3, 2, 'Roma', 'roma@gmail.com', '0814577554', 'Cimahi', 'Dona', 'roma@gmail.com', '081245487845', 'Bali', 'baju', '5', 'Regular', 'Rp25.000', 'Diterima', '2023-01-24 11:10:15'),
(4, 2, 'Roma', 'roma@gmail.com', '0814577554', 'Cimahi', 'Dona', 'roma@gmail.com', '081245487845', 'Bali', 'baju', '5', 'Regular', 'Rp25.000', 'Diterima', '2023-01-24 11:10:26'),
(5, 2, 'Rita', 'rita@gmail.com', '021656568', 'bali', 'rima', 'rita@gmail.com', '08124215499', 'bandung', 'baju', '8', 'Express', 'Rp30.000', 'Diterima', '2023-01-24 11:19:03'),
(6, 2, 'Rita', 'rita@gmail.com', '021656568', 'bali', 'rima', 'rita@gmail.com', '08124215499', 'bandung', 'baju', '8', 'Express', 'Rp30.000', 'Diterima', '2023-01-24 11:19:19'),
(7, 2, 'Shelvi', 'sel@gmail.com', '2314645', 'jakarta', 'indah', 'sel@gmail.com', '081247224', 'cimahi', 'celana', '3', 'Regular', 'Rp20.000', 'Diterima', '2023-01-24 11:32:38'),
(10, 3, 'Emil', 'emil@gmail.com', '08454525', 'Jakarta', 'Shafa', 'emil@gmail.com', '084545125', 'Malang', 'Celana', '7', 'Express', 'Rp30.000', 'Diterima', '2023-01-25 18:31:35'),
(12, 3, 'Dona', 'dona@gmail.com', '08587245444', 'Bandung', 'Nadia', 'nadia@gmail.com', '0845745454', '`German', 'Rok', '4', 'Regular', 'Rp20.000', 'Diterima', '2023-01-27 17:02:03'),
(13, 4, 'Nando', 'nando@gmail.com', '08574122554544', 'Jagakarsa', 'Lusiana', 'lusi@gmail.com', '08458784578', 'Cikarang', 'Gamis', '6', 'Express', 'Rp30.000', 'Diterima', '2023-01-27 17:20:24'),
(14, 4, 'taufik', 'taufik@gmail.com', '084574557', 'Lampung', 'Nana', 'nana@gmail.com', '0812454545', 'Semarang', 'Handuk', '1', 'Sameday', 'Rp30.000', 'Diterima', '2023-01-27 17:38:06'),
(15, 4, 'Romeo', 'roemo@gmail.com', '0858911144544', 'Balaraja', 'Juliet', 'juli@gmail.com', '08454574544', 'Pisangan', 'Mahkota', '7', 'Sameday', 'Rp35.000', 'Diterima', '2023-01-28 10:51:08'),
(16, 2, 'Sulis', 'sulis@gmail.com', '021242454', 'Banjar', 'Tia', 'tia@gmail.com', '021457863', 'Lampung', 'Lampu', '4', 'Sameday', 'Rp30.000', 'Diterima', '2023-01-28 11:18:40'),
(17, 3, 'Imel', 'imel@gmail.com', '021453798', 'Cimahi', 'Lintang', 'lintang@gmail.com', '02146633474', 'Lampung', 'Helm', '2', 'Sameday', 'Rp30.000', 'Diterima', '2023-01-28 11:58:20'),
(18, 3, 'Dorothy', 'dorothy@gmail.com', '02145736666', 'Banyuwangi', 'Diana', 'diana@gmail.com', '02134578966', 'Bali', 'Celana', '1', 'Regular', 'Rp20.000', 'Diterima', '2023-01-28 12:03:26'),
(21, 3, 'Neng', 'neng@gmail.com', '02145757754', 'Jalan Kita', 'Dita', 'dita@gmail.com', '087564143', 'Jalan Berdua', 'Bantal & Guling', '1', 'Express', 'Rp25.000', 'Diterima', '2023-01-28 17:39:57'),
(22, 3, 'Najmi', 'naj@gmail.com', '0214545477', 'Jogja', 'Albert', 'alb@gmail.com', '0213547558', 'Banten', 'Baju', '4', 'Express', 'Rp25.000', 'Diterima', '2023-02-01 20:01:20'),
(23, 2, 'Sasha', 'sas@gmail.com', '021345755', 'Jakarta selatan', 'Novs', 'nova@mail.com', '0213458754', 'Bekasi barat', 'Sepatu', '6', 'Express', 'Rp30.000', 'Diterima', '2023-02-01 20:32:46'),
(24, 4, 'Danilo', 'danilo@gmail.com', '02143855', 'Brazil', 'Ronaldo', 'ronal@gmail.com', '021555466', 'Portugal', 'Baju Timnas', '10', 'Sameday', 'Rp40.000', 'Diterima', '2023-02-01 20:40:18'),
(25, 6, 'Sinta', 'sinta@gmail.com', '02143557244', 'Jalan malaka selatan No.1', 'Dania', 'dani@gmail.com', '0213547577', 'Jalan Sungai atas 1 No.2', 'Baju', '5', 'Sameday', 'Rp35.000', 'Diterima', '2023-02-02 00:30:09');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_status`
--

CREATE TABLE `tbl_status` (
  `id_status` int(11) NOT NULL,
  `id_ekspedisi` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `waktu_update` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_status`
--

INSERT INTO `tbl_status` (`id_status`, `id_ekspedisi`, `status`, `waktu_update`) VALUES
(1, 1, 'Diterima', '2023-01-24 00:54:34'),
(2, 2, 'Diterima', '2023-01-24 11:11:33'),
(3, 3, 'Diterima', '2023-01-24 11:11:33'),
(4, 4, 'Diterima', '2023-01-24 11:11:33'),
(5, 5, 'Diterima', '2023-01-24 11:20:22'),
(6, 6, 'Diterima', '2023-01-24 11:20:22'),
(7, 7, 'Diterima', '2023-01-25 18:32:41'),
(10, 10, 'Diterima', '2023-01-25 18:32:41'),
(12, 12, 'Diterima', '2023-01-27 17:03:10'),
(13, 13, 'Diterima', '2023-01-27 17:21:27'),
(14, 14, 'Diterima', '2023-01-27 17:39:20'),
(15, 15, 'Diterima', '2023-01-28 10:52:13'),
(16, 16, 'Diterima', '2023-01-28 11:19:41'),
(17, 17, 'Diterima', '2023-01-28 12:04:29'),
(18, 18, 'Diterima', '2023-01-28 12:04:29'),
(21, 21, 'Diterima', '2023-01-28 17:41:19'),
(22, 22, 'Diterima', '2023-02-01 20:02:35'),
(23, 23, 'Diterima', '2023-02-01 20:33:57'),
(24, 24, 'Diterima', '2023-02-01 20:41:27'),
(25, 25, 'Diterima', '2023-02-02 00:31:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `admin_email` (`email`),
  ADD KEY `email` (`email`);

--
-- Indexes for table `tbl_ekspedisi`
--
ALTER TABLE `tbl_ekspedisi`
  ADD PRIMARY KEY (`id_ekspedisi`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tbl_status`
--
ALTER TABLE `tbl_status`
  ADD PRIMARY KEY (`id_status`),
  ADD KEY `id_ekspedisi` (`id_ekspedisi`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_ekspedisi`
--
ALTER TABLE `tbl_ekspedisi`
  MODIFY `id_ekspedisi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tbl_status`
--
ALTER TABLE `tbl_status`
  MODIFY `id_status` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
