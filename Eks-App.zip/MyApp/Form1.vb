﻿Imports System.Windows

Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GroupBox1.Text = ""
        Button1.Text = "START"
        Label1.Hide()
        Label2.Hide()
        Label1.Text = "Loading ...."
        Label2.Text = "%"
        ProgressBar1.Hide()


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ProgressBar1.Show()
        Label1.Show()
        Label2.Show()
        Timer1.Start()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        'untuk menghitung waktu berjalan nya
        If ProgressBar1.Value < 100 Then
            ProgressBar1.Value += 2

        ElseIf ProgressBar1.Value = 100 Then
            Timer1.Stop()
            MessageBox.Show("Aplikasi Siap ", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
            MsgBox("Memulai Aplikasi", MsgBoxStyle.Information, "Informasi")
            koneksi()
            Me.Hide()
            Form2.Show()
        End If
        'perintah untuk membuat loading info
        If ProgressBar1.Value = 20 Then
            Label1.ForeColor = Color.Black
            Label1.Text = "Mempersiapkan Data Pertama"
            ProgressBar1.ForeColor = Color.Orange
        ElseIf ProgressBar1.Value = 40 Then
            Label1.ForeColor = Color.Red
            Label1.Text = "Mempersiapkan Data Kedua"
            ProgressBar1.ForeColor = Color.Orange
        ElseIf ProgressBar1.Value = 50 Then
            Label1.ForeColor = Color.Green
            Label1.Text = "Mempersiapkan Data Ketiga"
            ProgressBar1.ForeColor = Color.Orange
        ElseIf ProgressBar1.Value = 60 Then
            Label1.ForeColor = Color.Gold
            Label1.Text = "Mempersiapkan Data Keempat"
            ProgressBar1.ForeColor = Color.Orange
        ElseIf ProgressBar1.Value = 70 Then
            Label1.ForeColor = Color.MediumPurple
            Label1.Text = "Mempersiapkan Data Kelima"
            ProgressBar1.ForeColor = Color.Orange
        ElseIf ProgressBar1.Value = 80 Then
            Label1.ForeColor = Color.Orange
            Label1.Text = "Mempersiapkan Data Ketujuh"
            ProgressBar1.ForeColor = Color.Orange
        ElseIf ProgressBar1.Value = 90 Then
            Label1.ForeColor = Color.Red
            Label1.Text = "Mempersiapkan Data Kedelapan"
            ProgressBar1.ForeColor = Color.Orange
        ElseIf ProgressBar1.Value = 100 Then
            Label1.ForeColor = Color.DarkGreen
            Label1.Text = "Mempersiapkan Data Kesembilan"
            ProgressBar1.ForeColor = Color.Orange
        End If
        'perintah untuk percentage
        Label2.Text = Math.Round((ProgressBar1.Value / 100) * 100, 2) & "%"
    End Sub




End Class
