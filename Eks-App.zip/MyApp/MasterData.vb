﻿Imports System.ComponentModel.Design
Imports System.Drawing.Printing
Imports MySql.Data.MySqlClient

Public Class MasterData
    Dim row As DataRow
    Dim dt As New DataTable
    Private Sub MasterData_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        koneksi()

        Hariini()

        Bulanini()

        Tahunini()

        AllData()

        ListView1.Columns.Add("ID EXP", HorizontalAlignment.Center)
        ListView1.Columns.Add("Nama Admin", HorizontalAlignment.Center)
        ListView1.Columns.Add("Email Admin", HorizontalAlignment.Center)

        ListView1.Columns.Add("Nama Pengirim", HorizontalAlignment.Center)
        ListView1.Columns.Add("Email Pengirim", HorizontalAlignment.Center)
        ListView1.Columns.Add("No Pengirim", HorizontalAlignment.Center)
        ListView1.Columns.Add("Alamat Pengirim", HorizontalAlignment.Center)

        ListView1.Columns.Add("Nama Penerima", HorizontalAlignment.Center)
        ListView1.Columns.Add("Email Penerima", HorizontalAlignment.Center)
        ListView1.Columns.Add("No Penerima", HorizontalAlignment.Center)
        ListView1.Columns.Add("Alamat Penerima", HorizontalAlignment.Center)

        ListView1.Columns.Add("Nama Barang", HorizontalAlignment.Center)
        ListView1.Columns.Add("Berat Barang (kg)", HorizontalAlignment.Center)
        ListView1.Columns.Add("Layanan Antar", HorizontalAlignment.Center)
        ListView1.Columns.Add("Biaya Pengantaran", HorizontalAlignment.Center)

        ListView1.Columns.Add("Status Pengiriman", HorizontalAlignment.Center)

        ListView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent)


        ListView1.Columns.Add("Waktu Input", HorizontalAlignment.Center)
        ListView1.View = View.Details
        ListView1.FullRowSelect = True
        ListView1.GridLines = True

        Dim getMasterData = "SELECT e.id_ekspedisi AS 'ID Ekspedisi', a.name as 'Nama Admin', a.email as 'Email Admin',e.nama_pengirim as 'Nama Pengirim', e.email_pengirim as 'Email Pengirim', e.no_pengirim as 'No Pengirim', e.alamat_pengirim as 'Alamat Pengirim', e.nama_penerima as 'Nama Penerima', e.email_penerima as 'Email Penerima', e.no_penerima as 'No Penerima', e.alamat_penerima as 'Alamat Penerima', e.nama_barang as 'Nama Barang', e.berat_barang as 'Berat Barang', e.layanan_antar as 'Layanan Antar', e.biaya_ekspedisi as 'Biaya Pengantaran', s.status as 'Status Pengiriman', e.waktu_input as 'Waktu Input' FROM tbl_admin a JOIN tbl_ekspedisi e ON a.user_id = e.user_id JOIN tbl_status s ON e.id_ekspedisi = s.id_ekspedisi ORDER by e.id_ekspedisi DESC"

        da = New MySqlDataAdapter(getMasterData, con)
        ds = New DataSet
        da.Fill(ds, "data")

        Dim getPrintData = "SELECT e.id_ekspedisi AS 'ID EXP', e.nama_pengirim as 'Nama Pengirim', e.no_pengirim as 'No Pengirim',  e.nama_penerima as 'Nama Penerima', e.no_penerima as 'No Penerima', e.alamat_penerima as 'Alamat Penerima', e.nama_barang as 'Nama Barang', e.berat_barang as 'Berat (Kg)', e.layanan_antar as 'Layanan Antar', e.biaya_ekspedisi as 'Biaya', s.status as 'Status', e.waktu_input as 'Waktu Input' FROM tbl_admin a JOIN tbl_ekspedisi e ON a.user_id = e.user_id JOIN tbl_status s ON e.id_ekspedisi = s.id_ekspedisi ORDER by e.id_ekspedisi DESC"

        cmd = New MySqlCommand(getPrintData, con)
        da = New MySqlDataAdapter(cmd)
        dt = New DataTable
        da.Fill(dt)


        If ds.Tables("data").Rows.Count > 0 Then
            For Each row As DataRow In ds.Tables("data").Rows
                Dim item As New ListViewItem(row("ID Ekspedisi").ToString())
                item.SubItems.Add(row("Nama Admin").ToString())
                item.SubItems.Add(row("Email Admin").ToString())
                item.SubItems.Add(row("Nama Pengirim").ToString())
                item.SubItems.Add(row("Email Pengirim").ToString())
                item.SubItems.Add(row("No Pengirim").ToString())
                item.SubItems.Add(row("Alamat Pengirim").ToString())
                item.SubItems.Add(row("Nama Penerima").ToString())
                item.SubItems.Add(row("Email Penerima").ToString())
                item.SubItems.Add(row("No Penerima").ToString())
                item.SubItems.Add(row("Alamat Penerima").ToString())
                item.SubItems.Add(row("Nama Barang").ToString())
                item.SubItems.Add(row("Berat Barang").ToString())
                item.SubItems.Add(row("Layanan Antar").ToString())
                item.SubItems.Add(row("Biaya Pengantaran").ToString())
                item.SubItems.Add(row("Status Pengiriman").ToString())
                item.SubItems.Add(row("Waktu Input").ToString())
                ListView1.Items.Add(item)
            Next

        Else
            ListView1.Clear()
            ListView1.GridLines = False
            Dim item As New ListViewItem("Data tidak ditemukan.")
            ListView1.Items.Add(item)
        End If
        For Each col As ColumnHeader In ListView1.Columns
            col.Width = -2
        Next

        DataGridView1.DataSource = dt
        DataGridView1.ReadOnly = True
        DataGridView1.AllowUserToAddRows = False
        DataGridView1.AllowUserToDeleteRows = False
        DataGridView1.AllowUserToOrderColumns = False
        DataGridView1.AllowUserToResizeRows = False
        DataGridView1.AllowUserToResizeColumns = False
    End Sub

    Sub AllData()
        Dim allData As String = " SELECT COUNT(id_ekspedisi) AS 'Jumlah Seluruh Data' FROM tbl_ekspedisi"
        da = New MySqlDataAdapter(allData, con)
        ds = New DataSet
        da.Fill(ds, "allData")

        If ds.Tables("allData").Rows.Count > 0 Then
            For Each row As DataRow In ds.Tables("allData").Rows
                Label4.Text = row("Jumlah Seluruh Data").ToString()

            Next
            Label5.Text = "Total Data : " & ds.Tables("allData").Rows(0)(0).ToString()
        Else
            Label4.Text = "0"
        End If


    End Sub
    Sub Hariini()

        Dim getDataEkspedisiHariIni As String = "SELECT COUNT(id_ekspedisi) as 'Jumlah Ekspedisi Hari Ini' FROM tbl_ekspedisi WHERE DATE(waktu_input) = CURDATE()"

        da = New MySqlDataAdapter(getDataEkspedisiHariIni, con)
        ds = New DataSet
        da.Fill(ds, "dataEkspedisiHariIni")


        If ds.Tables("dataEkspedisiHariIni").Rows.Count > 0 Then
            For Each row As DataRow In ds.Tables("dataEkspedisiHariIni").Rows
                Label1.Text = row("Jumlah Ekspedisi Hari Ini").ToString()
            Next

        Else
            Label1.Text = "0"
        End If

    End Sub

    Sub Bulanini()
        Dim getDataEkspedisiBulanIni As String = "SELECT COUNT(id_ekspedisi) as 'Jumlah Ekspedisi Bulan Ini' FROM tbl_ekspedisi WHERE MONTH(waktu_input) = MONTH(CURDATE())"

        da = New MySqlDataAdapter(getDataEkspedisiBulanIni, con)
        ds = New DataSet
        da.Fill(ds, "dataEkspedisiBulanIni")


        If ds.Tables("dataEkspedisiBulanIni").Rows.Count > 0 Then
            For Each row As DataRow In ds.Tables("dataEkspedisiBulanIni").Rows
                Label2.Text = row("jumlah Ekspedisi Bulan Ini").ToString()
            Next

        Else
            Label2.Text = "0"
        End If

    End Sub

    Sub Tahunini()
        Dim getDataEkspedisiTahunIni As String = "SELECT COUNT(id_ekspedisi) as 'Jumlah Ekspedisi Tahun Ini' FROM tbl_ekspedisi WHERE YEAR(waktu_input) = YEAR(CURDATE())"

        da = New MySqlDataAdapter(getDataEkspedisiTahunIni, con)
        ds = New DataSet
        da.Fill(ds, "dataEkspedisiTahunIni")


        If ds.Tables("dataEkspedisiTahunIni").Rows.Count > 0 Then
            For Each row As DataRow In ds.Tables("dataEkspedisiTahunIni").Rows
                Label3.Text = row("Jumlah Ekspedisi Tahun Ini").ToString()
            Next

        Else
            Label3.Text = "0"
        End If

    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click


        If MonthCalendar1.SelectionRange.Start <> Date.MinValue Then
            Dim tanggal As String = MonthCalendar1.SelectionRange.Start.ToString("yyyy-MM-dd")

            Dim query As String = "SELECT e.id_ekspedisi AS 'ID Ekspedisi', a.name as 'Nama Admin', a.email as 'Email Admin',e.nama_pengirim as 'Nama Pengirim', e.email_pengirim as 'Email Pengirim', e.no_pengirim as 'No Pengirim', e.alamat_pengirim as 'Alamat Pengirim', e.nama_penerima as 'Nama Penerima', e.email_penerima as 'Email Penerima', e.no_penerima as 'No Penerima', e.alamat_penerima as 'Alamat Penerima', e.nama_barang as 'Nama Barang', e.berat_barang as 'Berat Barang', e.layanan_antar as 'Layanan Antar', e.biaya_ekspedisi as 'Biaya Pengantaran', s.status as 'Status Pengiriman', e.waktu_input as 'Waktu Input' FROM tbl_admin a JOIN tbl_ekspedisi e ON a.user_id = e.user_id JOIN tbl_status s ON e.id_ekspedisi = s.id_ekspedisi WHERE DATE(waktu_input) = '" & tanggal & "'"

            da = New MySqlDataAdapter(query, con)
            ds = New DataSet
            da.Fill(ds, "dataEkspedisi")

            ListView1.Items.Clear()
            If ds.Tables("dataEkspedisi").Rows.Count > 0 Then
                For Each row As DataRow In ds.Tables("dataEkspedisi").Rows
                    Dim item As New ListViewItem(row("ID Ekspedisi").ToString())
                    item.SubItems.Add(row("Nama Admin").ToString())
                    item.SubItems.Add(row("Email Admin").ToString())
                    item.SubItems.Add(row("Nama Pengirim").ToString())
                    item.SubItems.Add(row("Email Pengirim").ToString())
                    item.SubItems.Add(row("No Pengirim").ToString())
                    item.SubItems.Add(row("Alamat Pengirim").ToString())
                    item.SubItems.Add(row("Nama Penerima").ToString())
                    item.SubItems.Add(row("Email Penerima").ToString())
                    item.SubItems.Add(row("No Penerima").ToString())
                    item.SubItems.Add(row("Alamat Penerima").ToString())
                    item.SubItems.Add(row("Nama Barang").ToString())
                    item.SubItems.Add(row("Berat Barang").ToString())
                    item.SubItems.Add(row("Layanan Antar").ToString())
                    item.SubItems.Add(row("Biaya Pengantaran").ToString())
                    item.SubItems.Add(row("Status Pengiriman").ToString())
                    item.SubItems.Add(row("Waktu Input").ToString())
                    ListView1.Items.Add(item)
                Next
                Label5.Text = "Data ditemukan: " & ds.Tables("dataEkspedisi").Rows.Count.ToString
            Else
                ListView1.GridLines = False
                MsgBox("Tidak ada data ekspedisi pada tanggal tersebut.")
                Dim item As New ListViewItem("Data Kosong")
                ListView1.Items.Add(item)
                Label5.Text = "Data ditemukan: 0"
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ListView1.Items.Clear()
        Dim getMasterData = "SELECT e.id_ekspedisi AS 'ID Ekspedisi', a.name as 'Nama Admin', a.email as 'Email Admin',e.nama_pengirim as 'Nama Pengirim', e.email_pengirim as 'Email Pengirim', e.no_pengirim as 'No Pengirim', e.alamat_pengirim as 'Alamat Pengirim', e.nama_penerima as 'Nama Penerima', e.email_penerima as 'Email Penerima', e.no_penerima as 'No Penerima', e.alamat_penerima as 'Alamat Penerima', e.nama_barang as 'Nama Barang', e.berat_barang as 'Berat Barang', e.layanan_antar as 'Layanan Antar', e.biaya_ekspedisi as 'Biaya Pengantaran', s.status as 'Status Pengiriman', e.waktu_input as 'Waktu Input' FROM tbl_admin a JOIN tbl_ekspedisi e ON a.user_id = e.user_id JOIN tbl_status s ON e.id_ekspedisi = s.id_ekspedisi ORDER by e.id_ekspedisi DESC"

        da = New MySqlDataAdapter(getMasterData, con)
        ds = New DataSet
        da.Fill(ds, "data")

        If ds.Tables("data").Rows.Count > 0 Then
            For Each row As DataRow In ds.Tables("data").Rows
                Dim item As New ListViewItem(row("ID Ekspedisi").ToString())
                item.SubItems.Add(row("Nama Admin").ToString())
                item.SubItems.Add(row("Email Admin").ToString())
                item.SubItems.Add(row("Nama Pengirim").ToString())
                item.SubItems.Add(row("Email Pengirim").ToString())
                item.SubItems.Add(row("No Pengirim").ToString())
                item.SubItems.Add(row("Alamat Pengirim").ToString())
                item.SubItems.Add(row("Nama Penerima").ToString())
                item.SubItems.Add(row("Email Penerima").ToString())
                item.SubItems.Add(row("No Penerima").ToString())
                item.SubItems.Add(row("Alamat Penerima").ToString())
                item.SubItems.Add(row("Nama Barang").ToString())
                item.SubItems.Add(row("Berat Barang").ToString())
                item.SubItems.Add(row("Layanan Antar").ToString())
                item.SubItems.Add(row("Biaya Pengantaran").ToString())
                item.SubItems.Add(row("Status Pengiriman").ToString())
                item.SubItems.Add(row("Waktu Input").ToString())
                ListView1.Items.Add(item)
            Next
        Else
            ListView1.Clear()
            ListView1.GridLines = False
            Dim item As New ListViewItem("Data tidak ditemukan.")
            ListView1.Items.Add(item)
            Label5.Text = "Data ditemukan: 0"
        End If
        For Each col As ColumnHeader In ListView1.Columns
            col.Width = -2
        Next
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        Me.PrintDocument1.DefaultPageSettings.Landscape = True

        ' menambahkan margin pada dokumen cetak
        Me.PrintDocument1.DefaultPageSettings.Margins = New Margins(10, 10, 10, 10)

        Me.PrintDocument1.DefaultPageSettings.PaperSize = New PaperSize("Custom", 1000, 2000)



        ' menentukan dokumen yang akan dicetak
        PrintPreviewDialog1.Document = PrintDocument1
        PrintPreviewDialog1.ShowDialog()
    End Sub



    Private Sub PrintDocument1_PrintPage(sender As Object, e As PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim yPos As Single = 0
        Dim count As Integer = 0
        ' create a font for text
        Dim printFont As New Font("Arial", 10)

        ' Add title header
        Dim titleSize As SizeF = e.Graphics.MeasureString("Data Ekspedisi", New Font("Arial", 14, FontStyle.Bold))
        e.Graphics.DrawString("Data Ekspedisi", New Font("Arial", 14, FontStyle.Bold), Brushes.Black, (e.PageBounds.Width - titleSize.Width) / 2, yPos)

        ' Add column headers
        yPos = 40
        For i As Integer = 0 To DataGridView1.Columns.Count - 1
            Dim stringSize As SizeF = e.Graphics.MeasureString(DataGridView1.Columns(i).HeaderText, printFont)
            e.Graphics.DrawString(DataGridView1.Columns(i).HeaderText, printFont, Brushes.Black, (150 * (i) + (150 - stringSize.Width) / 2), yPos)
            e.Graphics.DrawRectangle(Pens.Black, New Rectangle(New Point(CInt(150 * (i)), CInt(yPos)), New Size(150, printFont.Height)))
        Next

        ' Loop through each row in the DataGridView
        yPos = 60
        For Each row As DataGridViewRow In DataGridView1.Rows
            Dim xPos As Single = 0
            ' Loop through each column in the row
            For i As Integer = 0 To row.Cells.Count - 1
                Dim stringSize As SizeF = e.Graphics.MeasureString(row.Cells(i).Value.ToString(), printFont)
                ' Add Y position for subitem
                yPos = count * printFont.GetHeight(e.Graphics) + 60
                e.Graphics.DrawString(row.Cells(i).Value.ToString(), printFont, Brushes.Black, xPos + (150 - stringSize.Width) / 2, yPos)
                e.Graphics.DrawRectangle(Pens.Black, New Rectangle(New Point(CInt(xPos), CInt(yPos)), New Size(150, printFont.Height)))
                xPos += 150
            Next
            count += 1
        Next
    End Sub





    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub GroupBox2_Enter(sender As Object, e As EventArgs) Handles GroupBox2.Enter

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub GroupBox3_Enter(sender As Object, e As EventArgs) Handles GroupBox3.Enter

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub MonthCalendar1_DateSelected(sender As Object, e As DateRangeEventArgs) Handles MonthCalendar1.DateSelected

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub GroupBox4_Enter(sender As Object, e As EventArgs) Handles GroupBox4.Enter

    End Sub

    Private Sub MonthCalendar1_DateChanged(sender As Object, e As DateRangeEventArgs) Handles MonthCalendar1.DateChanged

    End Sub

    Private Sub PrintPreviewControl1_Click(sender As Object, e As EventArgs) Handles PrintPreviewControl1.Click

    End Sub
End Class