﻿Imports MySql.Data.MySqlClient
Imports System.Reflection.Emit
Imports System.Security.Cryptography
Imports System.Text
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Form6
    Private Sub Form6_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'nomor()

    End Sub


    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        'cek apakah textbox kosong
        If TextBox1.Text = "" Or TextBox2.Text = "" Then
            MsgBox("Mohon lengkapi data terlebih dahulu")
        ElseIf TextBox1.Text <> TextBox2.Text Then
            MsgBox("Maaf Password tidak sesuai")
        Else
            'hash password baru
            Dim hashAlgorithm As HashAlgorithm = New SHA256CryptoServiceProvider()
            Dim plaintextBytes() As Byte = Encoding.UTF8.GetBytes(TextBox1.Text)
            Dim hashBytes() As Byte = hashAlgorithm.ComputeHash(plaintextBytes)
            Dim hash As String = BitConverter.ToString(hashBytes)
            hash = hash.Replace("-", "")
            'update password baru ke database
            Dim updatePassword As String = "UPDATE tbl_admin SET password = '" & hash & "' WHERE email = '" & GlobalVariables.email & "'"
            cmd = New MySqlCommand(updatePassword, con)
            cmd.ExecuteNonQuery()
            MsgBox("Password berhasil diubah")
            TextBox1.Text = ""
            TextBox2.Text = ""
        End If
    End Sub
End Class