﻿Imports System.Security.Cryptography
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports MySql.Data.MySqlClient

Public Class Form7
    Dim jl As String
    Dim db As Integer
    Dim dt As New DataTable

    Private Sub Form7_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call jmlbrt()
        Button2.Enabled = False
        Me.ComboBox1.DropDownStyle = ComboBoxStyle.DropDownList


    End Sub



    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Select Case True
            Case RadioButton1.Checked
                jl = RadioButton1.Text
            Case RadioButton2.Checked
                jl = RadioButton2.Text
            Case RadioButton3.Checked
                jl = RadioButton3.Text
        End Select


        Dim emailRegex As New Regex("^[_a-z0-9-]+(.[a-z0-9-]+)@[a-z0-9-]+(.[a-z0-9-]+)*(.[a-z]{2,4})$")
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Or TextBox6.Text = "" Or TextBox7.Text = "" Or TextBox8.Text = "" Or TextBox9.Text = "" Then
            MessageBox.Show("Semua field harus diisi!")
        ElseIf Not emailRegex.IsMatch(TextBox2.Text) Or Not emailRegex.IsMatch(TextBox6.Text) Then
            MessageBox.Show("Email harus memiliki format yang benar!")
        Else
            If Me.RadioButton1.Checked OrElse Me.RadioButton2.Checked OrElse Me.RadioButton3.Checked = True Then
                'query untuk mengambil id_user dari email yang digunakan saat login
                Dim getId As String = "SELECT user_id FROM tbl_admin WHERE email = '" & GlobalVariables.email & "'"
                cmd = New MySqlCommand(getId, con)
                Dim id_user As String = cmd.ExecuteScalar()

                'Dim status_pengiriman As String = "Proses" 'nilai default status pengiriman
                ListBox1.Items.Clear()
                ListBox2.Items.Clear()
                ListBox3.Items.Clear()

                MsgBox("Memasukkan Data")


                'Form4.PictureBox1.Show()
                'Form4.Label1.Show()

                'Form4.PictureBox2.Show()
                'Form4.Label2.Show()

                'Form4.PictureBox3.Show()
                'Form4.Label3.Show()


                Me.Button1.Enabled = False
                Me.TextBox1.Enabled = False
                Me.TextBox2.Enabled = False
                Me.TextBox3.Enabled = False

                Me.TextBox4.Enabled = False
                Me.TextBox5.Enabled = False
                Me.TextBox6.Enabled = False

                Me.TextBox7.Enabled = False
                Me.TextBox8.Enabled = False
                Me.TextBox9.Enabled = False
                Me.RadioButton1.Enabled = False
                Me.RadioButton2.Enabled = False
                Me.RadioButton3.Enabled = False
                Me.ComboBox1.Enabled = False
                With Me.ListBox1
                    .Items.Add("Detail Data Ekspedisi")
                    .Items.Add("====================================================")
                    .Items.Add("Data Pengirim")
                    .Items.Add("====================================================")
                    .Items.Add("")
                    .Items.Add("Nama : " & TextBox1.Text)
                    .Items.Add("Email : " & TextBox2.Text)
                    .Items.Add("No Telp/Hp : " & TextBox3.Text)
                    .Items.Add("Alamat : " & TextBox4.Text)
                End With

                With Me.ListBox2

                    .Items.Add("====================================================")
                    .Items.Add("Data Penerima")
                    .Items.Add("====================================================")
                    .Items.Add("")
                    .Items.Add("Nama : " & TextBox5.Text)
                    .Items.Add("Email : " & TextBox6.Text)
                    .Items.Add("No Telp/Hp : " & TextBox7.Text)
                    .Items.Add("Alamat : " & TextBox8.Text)
                End With

                With Me.ListBox3
                    .Items.Add("====================================================")
                    .Items.Add("Data Barang dan Layanan")
                    .Items.Add("====================================================")
                    .Items.Add("")
                    .Items.Add("Nama Barang : " & TextBox9.Text)
                    .Items.Add("Berat Barang : " & ComboBox1.Text & "Kg")
                    .Items.Add("Jenis Layanan : " & jl)
                    .Items.Add("====================================================")
                    .Items.Add("Total Biaya : " & biaya(db))
                End With


            Else
                MsgBox("Layanan Belum dipilih")
            End If
        End If
    End Sub

    Sub bersih()
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
        TextBox7.Clear()
        TextBox8.Clear()
        TextBox9.Clear()

        TextBox1.Enabled = True
        TextBox2.Enabled = True
        TextBox3.Enabled = True
        TextBox4.Enabled = True
        TextBox5.Enabled = True
        TextBox6.Enabled = True
        TextBox7.Enabled = True
        TextBox8.Enabled = True
        TextBox9.Enabled = True

        Me.RadioButton1.Enabled = True
        Me.RadioButton2.Enabled = True
        Me.RadioButton3.Enabled = True
        Me.ComboBox1.Enabled = True

        ListBox1.Items.Clear()
        ListBox2.Items.Clear()
        ListBox3.Items.Clear()
        CheckBox1.Checked = False
        Button1.Enabled = True

    End Sub
    Function biaya(ByVal harga As Integer)
        Dim weight As Integer = ComboBox1.SelectedItem
        Dim cost As Integer = 0
        If weight >= 10 Then
            cost = 20000
        ElseIf weight >= 5 Then
            cost = 15000
        ElseIf weight >= 1 Then
            cost = 10000
        End If

        If RadioButton1.Checked = True Then
            cost += 10000
        End If
        If RadioButton2.Checked = True Then
            cost += 15000
        End If
        If RadioButton3.Checked = True Then
            cost += 20000
        End If

        Return FormatCurrency(cost, 0)
    End Function

    Sub jmlbrt()
        Dim berat(9) As Integer

        For i As Integer = 1 To 10
            berat(i - 1) = i
        Next

        ComboBox1.DataSource = berat

    End Sub

    Private Sub TextBox3_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs) Handles TextBox3.KeyPress
        If Not ((e.KeyChar >= "0" AndAlso e.KeyChar <= "9") OrElse e.KeyChar = vbBack) Then
            e.Handled = True
        End If

    End Sub

    Private Sub TextBox7_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs) Handles TextBox7.KeyPress
        If Not ((e.KeyChar >= "0" AndAlso e.KeyChar <= "9") OrElse e.KeyChar = vbBack) Then
            e.Handled = True
        End If

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        TextBox2.Text = TextBox2.Text.ToLower()

    End Sub

    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs) Handles TextBox6.TextChanged
        TextBox6.Text = TextBox6.Text.ToLower()

    End Sub

    Private Sub ContextMenuStrip1_Opening(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles ContextMenuStrip1.Opening

    End Sub

    Private Sub ContextMenuStrip2_Opening(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles ContextMenuStrip2.Opening

    End Sub

    Private Sub ContextMenuStrip3_Opening(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles ContextMenuStrip3.Opening

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Select Case True
            Case RadioButton1.Checked
                jl = RadioButton1.Text
            Case RadioButton2.Checked
                jl = RadioButton2.Text
            Case RadioButton3.Checked
                jl = RadioButton3.Text
        End Select

        Dim emailRegex As New Regex("^[_a-z0-9-]+(.[a-z0-9-]+)@[a-z0-9-]+(.[a-z0-9-]+)*(.[a-z]{2,4})$")
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Or TextBox6.Text = "" Or TextBox7.Text = "" Or TextBox8.Text = "" Or TextBox9.Text = "" Then
            MessageBox.Show("Semua field harus diisi!")
        ElseIf Not emailRegex.IsMatch(TextBox2.Text) Or Not emailRegex.IsMatch(TextBox6.Text) Then
            MessageBox.Show("Email harus memiliki format yang benar!")
        Else
            If RadioButton1.Checked OrElse RadioButton2.Checked OrElse RadioButton3.Checked = True Then
                'query untuk mengambil id_user dari email yang digunakan saat login
                Dim getId As String = "SELECT user_id FROM tbl_admin WHERE email = '" & GlobalVariables.email & "'"
                cmd = New MySqlCommand(getId, con)
                Dim id_user As String = cmd.ExecuteScalar()

                'mengambil Data dari form

                Dim nama_pengirim As String = TextBox1.Text
                Dim email_pengirim As String = TextBox2.Text
                Dim no_pengirim As String = TextBox3.Text
                Dim alamat_pengirim As String = TextBox4.Text
                Dim nama_penerima As String = TextBox5.Text
                Dim email_penerima As String = TextBox6.Text
                Dim no_penerima As String = TextBox7.Text
                Dim alamat_penerima As String = TextBox8.Text
                Dim nama_barang As String = TextBox9.Text
                Dim berat_barang As String = ComboBox1.Text
                Dim layanan_antar As String = jl
                Dim biaya_ekspedisi As String = biaya(db)
                Dim status_pengiriman As String = "Proses" 'nilai default status pengiriman

                'query untuk insert data ke tabel ekspedisi
                Dim insertEkspedisi As String = "INSERT INTO tbl_ekspedisi (user_id, nama_pengirim, email_pengirim, no_pengirim, alamat_pengirim, nama_penerima, email_penerima, no_penerima, alamat_penerima, nama_barang, berat_barang, layanan_antar, biaya_ekspedisi, status_pengiriman, waktu_input) VALUES ('" & id_user & "', '" & nama_pengirim & "', '" & email_pengirim & "', '" & no_pengirim & "', '" & alamat_pengirim & "', '" & nama_penerima & "', '" & email_penerima & "', '" & no_penerima & "', '" & alamat_penerima & "', '" & nama_barang & "', '" & berat_barang & "','" & layanan_antar & "', '" & biaya_ekspedisi & "', '" & status_pengiriman & "', NOW())"
                cmd = New MySqlCommand(insertEkspedisi, con) 'menghubungkan ke database dan table ekspedisi
                cmd.ExecuteNonQuery() 'mengeksekusi query insert
                'setelah data berhasil dimasukkan ke tabel ekspedisi, kita juga perlu memasukkan data ke tabel status pengiriman
                'query untuk mendapatkan ID ekspedisi terbaru yang baru saja dimasukkan ke tabel ekspedisi
                Dim getIdEkspedisi As String = "SELECT MAX(id_ekspedisi) FROM tbl_ekspedisi WHERE user_id = '" & id_user & "'"
                cmd = New MySqlCommand(getIdEkspedisi, con)
                Dim id_ekspedisi As String = cmd.ExecuteScalar()
                'query untuk insert data ke tabel status pengiriman
                Dim insertStatus As String = "INSERT INTO tbl_status (id_ekspedisi, status, waktu_update) VALUES ('" & id_ekspedisi & "', '" & status_pengiriman & "', NOW())"
                cmd = New MySqlCommand(insertStatus, con)
                cmd.ExecuteNonQuery()

                Dim selectEkspedisi As String = "SELECT e.id_ekspedisi AS 'ID Ekspedisi', u.name AS 'Admin', e.nama_pengirim AS 'Nama Pengirim', e.email_pengirim AS 'Email Pengirim', e.no_pengirim AS 'No Pengirim', e.alamat_pengirim AS 'Alamat Pengirim', e.nama_penerima AS 'Nama Penerima', e.email_penerima AS 'Email Penerima', e.no_penerima AS 'No Penerima', e.alamat_penerima AS 'Alamat Penerima', e.nama_barang AS 'Nama Barang', e.berat_barang AS 'Berat Barang', e.layanan_antar AS 'Layanan Antar', e.biaya_ekspedisi AS 'Biaya Ekspedisi', e.status_pengiriman AS 'Status Pengiriman', e.waktu_input AS 'Waktu Input' FROM tbl_ekspedisi e JOIN tbl_admin u ON e.user_id = u.user_id WHERE e.user_id = '" & id_user & "' ORDER BY id_ekspedisi DESC"
                cmd = New MySqlCommand(selectEkspedisi, con)
                da = New MySqlDataAdapter(cmd)
                dt = New DataTable
                da.Fill(dt)


                InformasiEkspedisi.DataGridView1.DataSource = dt
                InformasiEkspedisi.DataGridView1.ReadOnly = True
                InformasiEkspedisi.DataGridView1.AllowUserToAddRows = False
                InformasiEkspedisi.DataGridView1.AllowUserToDeleteRows = False
                InformasiEkspedisi.DataGridView1.AllowUserToOrderColumns = False
                InformasiEkspedisi.DataGridView1.AllowUserToResizeRows = False
                InformasiEkspedisi.DataGridView1.AllowUserToResizeColumns = False
                bersih()

                Me.Hide()
                InformasiEkspedisi.MdiParent = Form4
                InformasiEkspedisi.Show()


                MsgBox("Silakan cek pada menu Informasi Ekspedisi untuk melihat status ekspedisi")

            Else
                MsgBox("Layanan Belum dipilih")
            End If
        End If
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            Button2.Enabled = True
            ContextMenuStrip1.Enabled = False
            ContextMenuStrip2.Enabled = False
            ContextMenuStrip3.Enabled = False
        Else
            Button2.Enabled = False
            ContextMenuStrip1.Enabled = True
            ContextMenuStrip2.Enabled = True
            ContextMenuStrip3.Enabled = True

        End If
    End Sub

    Private Sub EditToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EditToolStripMenuItem.Click
        TextBox1.Enabled = True
        TextBox2.Enabled = True
        TextBox3.Enabled = True
        TextBox4.Enabled = True
        Button1.Enabled = True
    End Sub

    Private Sub ToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem1.Click
        TextBox5.Enabled = True
        TextBox6.Enabled = True
        TextBox7.Enabled = True
        TextBox8.Enabled = True
        Button1.Enabled = True
    End Sub

    Private Sub ToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem2.Click
        TextBox9.Enabled = True
        ComboBox1.Enabled = True
        RadioButton1.Enabled = True
        RadioButton2.Enabled = True
        RadioButton3.Enabled = True
        Button1.Enabled = True
    End Sub
End Class