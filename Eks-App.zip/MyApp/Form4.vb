﻿Imports System.Reflection.Emit
Imports MySql.Data.MySqlClient

Public Class Form4
    Private Sub ProfileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProfileToolStripMenuItem.Click


    End Sub

    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        koneksi()
        Dim getName As String = "SELECT name FROM tbl_admin WHERE email = '" & GlobalVariables.email & "'"
        cmd = New MySqlCommand(getName, con)
        Dim name As String = cmd.ExecuteScalar()

        MyAccountToolStripMenuItem.Text = "Hello " & name.ToUpper



    End Sub

    Private Sub FormEkspedisiToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FormEkspedisiToolStripMenuItem.Click




        Form6.Hide()
        Form5.Hide()

        Form7.MdiParent = Me
            Form7.Show()

    End Sub

    Private Sub MyAccountToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MyAccountToolStripMenuItem.Click
        Form5.MdiParent = Me
        Form5.Show()
        Form6.Hide()
        Form7.Hide()
        
        InformasiEkspedisi.Hide()
        MasterData.Hide()
        DataUser.Hide()
    End Sub


    Private Sub ChangePasswordToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ChangePasswordToolStripMenuItem.Click
        Form6.MdiParent = Me
        Form6.Show()
        Form7.Hide()
        Form5.Hide()

        InformasiEkspedisi.Hide()
        MasterData.Hide()
        DataUser.Hide()
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click

        Form5.Close()
        Form6.Close()
        Form7.Close()

        InformasiEkspedisi.Close()
        MasterData.Close()
        DataUser.Close()
        Form2.TextBox1.Clear()
        Form2.TextBox2.Clear()
        'clear global variable
        GlobalVariables.email = ""
        ''clear datagridview
        'Form9.DataGridView1.DataSource = Nothing
        'Form9.DataGridView1.Rows.Clear()
        'Form9.DataGridView1.Refresh()
        'show login form and hide current form
        Dim loginForm As New Form2
        loginForm.Show()
        Me.Close()
    End Sub

    Private Sub DataUserToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DataUserToolStripMenuItem.Click
        DataUser.MdiParent = Me
        DataUser.Show()
        Form5.Hide()
        Form6.Hide()
        Form7.Hide()

        InformasiEkspedisi.Hide()
        MasterData.Hide()
    End Sub

    Private Sub InformasiEkspedisiToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InformasiEkspedisiToolStripMenuItem.Click
        InformasiEkspedisi.MdiParent = Me
        InformasiEkspedisi.Show()
        Form7.Hide()
        Form5.Hide()
        Form6.Hide()
        DataUser.Hide()

        MasterData.Hide()
    End Sub

    Private Sub MasterDataEkspedisiToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MasterDataEkspedisiToolStripMenuItem.Click
        MasterData.MdiParent = Me
        MasterData.Show()
        DataUser.Hide()
        InformasiEkspedisi.Hide()

        Form7.Hide()
        Form5.Hide()
        Form6.Hide()

    End Sub





End Class