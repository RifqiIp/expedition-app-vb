﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports MySql.Data.MySqlClient

Public Class DataUser
    Private Sub DataUser_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim getAdminData As String = "SELECT a.name, a.email, COUNT(e.id_ekspedisi) AS jumlah_ekspedisi, MAX(e.waktu_input) AS terakhir_input FROM tbl_admin a JOIN tbl_ekspedisi e ON a.user_id = e.user_id WHERE a.role = 'admin' GROUP BY a.user_id"
        da = New MySqlDataAdapter(getAdminData, con)
        ds = New DataSet
        da.Fill(ds, "adminData")

        ListView1.Columns.Add("Nama", 100, HorizontalAlignment.Center)
        ListView1.Columns.Add("Email", 200, HorizontalAlignment.Center)
        ListView1.Columns.Add("Jumlah Ekspedisi", 150, HorizontalAlignment.Center)
        ListView1.Columns.Add("Terakhir Input", 150, HorizontalAlignment.Center)
        ListView1.View = View.Details
        ListView1.FullRowSelect = True
        ListView1.GridLines = True

        If ds.Tables("adminData").Rows.Count > 0 Then
            For Each row As DataRow In ds.Tables("adminData").Rows
                Dim item As New ListViewItem(row("name").ToString())
                item.SubItems.Add(row("email").ToString())
                If row("jumlah_ekspedisi").ToString() = "0" Then
                    item.SubItems.Add("Belum ada data")
                Else
                    item.SubItems.Add(row("jumlah_ekspedisi").ToString())
                End If
                item.SubItems.Add(row("terakhir_input").ToString())
                ListView1.Items.Add(item)
            Next
        Else
            ListView1.Columns.Clear()
            ListView1.GridLines = False
            ListView1.Columns.Add("Nama", 100, HorizontalAlignment.Center)
            ListView1.Columns.Add("Email", 200, HorizontalAlignment.Center)
            ListView1.Columns.Add("Jumlah Ekspedisi", 150, HorizontalAlignment.Center)
            ListView1.Columns.Add("Terakhir Input", 150, HorizontalAlignment.Center)
            Dim item As New ListViewItem("Data admin tidak ditemukan")
            ListView1.Items.Add(item)
        End If
        For Each col As ColumnHeader In ListView1.Columns
            col.Width = -2
        Next
    End Sub




End Class