﻿Imports System.Security.Cryptography
Imports System.Text
Imports MySql.Data.MySqlClient
Imports Mysqlx.XDevAPI.Relational

Public Class Form5
    ' Declare global variables

    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox1.Enabled = False
        TextBox2.Enabled = False
        TextBox3.Enabled = False
        TextBox4.Enabled = False
        Button2.Enabled = False


        koneksi()

        Dim getName As String = "SELECT name FROM tbl_admin WHERE email = '" & GlobalVariables.email & "'"
        cmd = New MySqlCommand(getName, con)
        Dim name As String = cmd.ExecuteScalar()


        Me.TextBox1.Text = name.ToUpper()

        Dim getEmail As String = "SELECT email FROM tbl_admin WHERE email = '" & GlobalVariables.email & "'"
        cmd = New MySqlCommand(getEmail, con)
        Dim Myemail As String = cmd.ExecuteScalar()
        Me.TextBox2.Text = Myemail.ToUpper()


        Dim getRole As String = "SELECT role FROM tbl_admin WHERE email = '" & GlobalVariables.email & "'"
        cmd = New MySqlCommand(getRole, con)
        Dim myRole As String = cmd.ExecuteScalar()

        Me.TextBox4.Text = myRole.ToUpper

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TextBox1.Enabled = True
        TextBox3.Enabled = True
        Button1.Enabled = False
        Button2.Enabled = True
    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If TextBox1.Text = "" Or TextBox3.Text = "" Then
            MsgBox("Nama, Email atau Password tidak boleh kosong")
        Else
            Dim cekPassword As String = "SELECT password FROM tbl_admin WHERE email = '" & Me.TextBox2.Text & "'"
            cmd = New MySqlCommand(cekPassword, con)
            Dim passwordDB As String = Convert.ToString(cmd.ExecuteScalar())
            Dim hashAlgorithm As HashAlgorithm = New SHA256CryptoServiceProvider()
            ' Convert the plaintext password to a byte array.
            Dim plaintextBytes() As Byte = Encoding.UTF8.GetBytes(Me.TextBox3.Text)
            ' Compute the hash.
            Dim hashBytes() As Byte = hashAlgorithm.ComputeHash(plaintextBytes)
            ' Convert the hash to a hexadecimal string.
            Dim hash As String = BitConverter.ToString(hashBytes)
            hash = hash.Replace("-", "")
            If passwordDB = hash Then
                Dim edit As String
                edit = "update tbl_admin set name ='" & Me.TextBox1.Text.ToLower() & "' where email = '" & Me.TextBox2.Text.ToLower() & "'"
                cmd = New MySqlCommand(edit, con) ' untuk menghubungkan ke database dan table lalu Update
                cmd.ExecuteNonQuery() ' mengeksekusi datanya
                MsgBox("Data Berhasil Diupdate")
                TextBox1.Enabled = False
                TextBox1.Text.ToUpper()
                TextBox3.Enabled = False
                TextBox3.Clear()
                Button1.Enabled = True
                Button2.Enabled = False
            Else
                MsgBox("Password yang dimasukkan salah")
            End If
        End If
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub
End Class
