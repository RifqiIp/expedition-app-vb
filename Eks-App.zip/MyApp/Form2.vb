﻿Imports System.Security.Cryptography
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports MySql.Data.MySqlClient

Public Class Form2

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub


    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        Me.Hide()
        Form3.Show()

    End Sub

    Private Sub Label4_MouseHover(sender As Object, e As EventArgs) Handles Label4.MouseHover
        Label4.ForeColor = Color.Red
    End Sub

    Private Sub Label4_MouseLeave(sender As Object, e As EventArgs) Handles Label4.MouseLeave
        Label4.ForeColor = Color.Black
    End Sub


    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        koneksi()
        If TextBox1.Text = "" Or TextBox2.Text = "" Then
            MsgBox("Email atau Password tidak boleh kosong")
        Else

            Dim email As String = Me.TextBox1.Text.ToLower()
            GlobalVariables.email = email
            Dim enteredPassword As String = Me.TextBox2.Text

            'Validate email with regex
            Dim emailRegex As New Regex("^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$")
            If emailRegex.IsMatch(email) Then
                'query untuk mengambil password yang tersimpan di database
                Dim getPassword As String = "SELECT password FROM tbl_admin WHERE email = '" & email & "'"
                cmd = New MySqlCommand(getPassword, con)
                Dim storedHash As String = cmd.ExecuteScalar()

                ' Create a new instance of the hash algorithm.
                Dim hashAlgorithm As HashAlgorithm = New SHA256CryptoServiceProvider()
                ' Convert the entered password to a byte array.
                Dim enteredBytes() As Byte = Encoding.UTF8.GetBytes(enteredPassword)
                ' Compute the hash of the entered password.
                Dim enteredHashBytes() As Byte = hashAlgorithm.ComputeHash(enteredBytes)
                ' Convert the hash to a hexadecimal string.
                Dim enteredHash As String = BitConverter.ToString(enteredHashBytes)
                enteredHash = enteredHash.Replace("-", "")

                ' Compare the entered hash with the stored hash
                If enteredHash = storedHash Then
                    'buat form yang akan dibuka setelah login berhasil
                    Dim getRole As String = "SELECT role FROM tbl_admin WHERE email = '" & email & "'"
                    cmd = New MySqlCommand(getRole, con)
                    Dim role As String = cmd.ExecuteScalar()
                    'cek role user
                    If role = "super admin" Then
                        MsgBox("Login Berhasil sebagai Super Admin")
                        'buat form superadmin yang akan dibuka setelah login berhasil
                        Dim formMenuUtama As New Form4
                        formMenuUtama.Show()
                        formMenuUtama.FormEkspedisiToolStripMenuItem.Visible = False
                        formMenuUtama.InformasiEkspedisiToolStripMenuItem.Visible = False

                        Me.Hide()
                    ElseIf role = "admin" Then
                        MsgBox("Login Berhasil sebagai Admin")
                        'buat form admin yang akan dibuka setelah login berhasil
                        Dim formMenuUtama As New Form4
                        formMenuUtama.Show()
                        formMenuUtama.DataUserToolStripMenuItem.Visible = False
                        formMenuUtama.MasterDataEkspedisiToolStripMenuItem.Visible = False
                        Me.Hide()
                    Else
                        MsgBox("Maaf, role tidak dikenali")
                    End If

                Else
                    'jika data tidak ditemukan, maka akan muncul pesan login gagal
                    MsgBox("Maaf, email atau password salah")
                End If
            Else
                MsgBox("Maaf, format email tidak valid")
            End If
        End If
    End Sub



End Class