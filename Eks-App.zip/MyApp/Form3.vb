﻿Imports System.Security.Cryptography
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports MySql.Data.MySqlClient
Imports Mysqlx.XDevAPI.Relational

Public Class Form3

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click
        Me.Hide()
        Form2.Show()
    End Sub

    Private Sub Label5_MouseHover(sender As Object, e As EventArgs) Handles Label5.MouseHover
        Label5.ForeColor = Color.Red
    End Sub

    Private Sub Label5_MouseLeave(sender As Object, e As EventArgs) Handles Label5.MouseLeave
        Label5.ForeColor = Color.Black
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        '------- Coding Simpan --------
        If Me.TextBox1.Text = "" Or Me.TextBox2.Text = "" Or Me.TextBox3.Text = "" Or Me.TextBox4.Text = "" Then
            MsgBox("Mohon lengkapi data terlebh dahulu")
        ElseIf Me.ComboBox1.Text = "" Then
            MsgBox("Role harus dipilih, tidak boleh kosong")
        ElseIf Me.TextBox3.Text <> TextBox4.Text Then
            MsgBox("Maaf Password tidak sesuai")
        Else
            Dim email As String = Me.TextBox2.Text.ToLower()
            Dim emailRegex As New Regex("^([\w.-]+)@([\w-]+)((.(\w){2,3})+)$")
            If emailRegex.IsMatch(email) Then
                'query untuk mengecek apakah email sudah terdaftar di database
                Dim cekEmail As String = "SELECT COUNT(*) FROM tbl_admin WHERE email = '" & Me.TextBox2.Text & "'"
                cmd = New MySqlCommand(cekEmail, con)
                Dim countEmail As Integer = Convert.ToInt32(cmd.ExecuteScalar())
                If countEmail > 0 Then
                    MsgBox("Maaf, email sudah digunakan, silahkan menggunakan email lain")
                Else
                    Dim cekRole As String = "SELECT COUNT(*) FROM tbl_admin WHERE role = 'super admin'"
                    cmd = New MySqlCommand(cekRole, con)
                    Dim countRole As Integer = Convert.ToInt32(cmd.ExecuteScalar())
                    If countRole > 0 And Me.ComboBox1.Text = "super admin" Then
                        MsgBox("Maaf, role super admin hanya boleh digunakan oleh satu akun saja")
                        ' Create a new instance of the hash algorithm.
                    Else
                        Dim hashAlgorithm As HashAlgorithm = New SHA256CryptoServiceProvider()
                        ' Convert the plaintext password to a byte array.
                        Dim plaintextBytes() As Byte = Encoding.UTF8.GetBytes(Me.TextBox3.Text)
                        ' Compute the hash.
                        Dim hashBytes() As Byte = hashAlgorithm.ComputeHash(plaintextBytes)
                        ' Convert the hash to a hexadecimal string.
                        Dim hash As String = BitConverter.ToString(hashBytes)
                        hash = hash.Replace("-", "")
                        Dim cekRoleAdmin As String = "SELECT COUNT(*) FROM tbl_admin WHERE role = 'super admin'"
                        cmd = New MySqlCommand(cekRoleAdmin, con)


                        'use this hash value to save in the database
                        Dim simpan As String
                        'call the function to generate the new ID
                        Dim role As String = ComboBox1.SelectedItem
                        MsgBox("Registration successful")
                        simpan = "insert into tbl_admin (name,email,password,role)values('" & Me.TextBox1.Text.ToLower() _
                        & "','" & Me.TextBox2.Text.ToLower() & "','" & hash & "','" & role & "')"
                        cmd = New MySqlCommand(simpan, con)
                        cmd.ExecuteNonQuery()
                        bersih()
                    End If
                End If
            Else
                MsgBox("Please enter a valid email address")
                Me.TextBox2.Focus()
            End If
        End If
    End Sub


    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        koneksi()
        ComboBox1.DropDownStyle = ComboBoxStyle.DropDownList
        ComboBox1.Items.Add("super admin")
        ComboBox1.Items.Add("admin")
    End Sub
    Sub bersih()
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        ComboBox1.Text = ""
        Me.Hide()
        Form2.Show()
    End Sub
End Class