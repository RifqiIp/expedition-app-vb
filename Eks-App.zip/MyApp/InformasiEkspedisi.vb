﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports MySql.Data.MySqlClient

Public Class InformasiEkspedisi
    Dim updateTimer As New Timer()
    Dim row As DataRow
    Dim dt As New DataTable
    Private Sub Form9_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        koneksi()

        updateTimer.Interval = 60000 '1 menit dalam milisecond
        updateTimer.Start()
        AddHandler updateTimer.Tick, AddressOf updateStatus
        DataGridView1.ReadOnly = True

        Dim getId As String = "SELECT user_id FROM tbl_admin WHERE email = '" & GlobalVariables.email & "'"
        cmd = New MySqlCommand(getId, con)
        Dim id_user As String = cmd.ExecuteScalar()


        Dim selectEkspedisi As String = "SELECT e.id_ekspedisi AS 'ID', u.name AS 'Admin', e.nama_pengirim AS 'Nama Pengirim', e.email_pengirim AS 'Email Pengirim', e.no_pengirim AS 'No Pengirim', e.alamat_pengirim AS 'Alamat Pengirim', e.nama_penerima AS 'Nama Penerima', e.email_penerima AS 'Email Penerima', e.no_penerima AS 'No Penerima', e.alamat_penerima AS 'Alamat Penerima', e.nama_barang AS 'Nama Barang', e.berat_barang AS 'Berat Barang', e.layanan_antar AS 'Layanan Antar', e.biaya_ekspedisi AS 'Biaya Ekspedisi', e.status_pengiriman AS 'Status Pengiriman', e.waktu_input AS 'Waktu Input' FROM tbl_ekspedisi e JOIN tbl_admin u ON e.user_id = u.user_id WHERE e.user_id = '" & id_user & "' ORDER BY id_ekspedisi DESC"
        cmd = New MySqlCommand(selectEkspedisi, con)
        da = New MySqlDataAdapter(cmd)
        dt = New DataTable
        da.Fill(dt)


        DataGridView1.DataSource = dt
        DataGridView1.ReadOnly = True
        DataGridView1.AllowUserToAddRows = False
        DataGridView1.AllowUserToDeleteRows = False
        DataGridView1.AllowUserToOrderColumns = False
        DataGridView1.AllowUserToResizeRows = False
        DataGridView1.AllowUserToResizeColumns = False
    End Sub
    Private Sub updateStatus(sender As Object, e As EventArgs)
        Dim getId As String = "SELECT user_id FROM tbl_admin WHERE email = '" & GlobalVariables.email & "'"
        cmd = New MySqlCommand(getId, con)
        Dim id_user As String = cmd.ExecuteScalar()
        'query untuk mengambil data ekspedisi yang statusnya "Proses"
        Dim selectEkspedisi As String = "SELECT id_ekspedisi FROM tbl_ekspedisi WHERE status_pengiriman = 'Proses' ORDER BY id_ekspedisi DESC"
        cmd = New MySqlCommand(selectEkspedisi, con)
        Dim dt As New DataTable
        da = New MySqlDataAdapter(cmd)
        da.Fill(dt)
        'looping setiap data ekspedisi yang statusnya "Proses"
        For Each row As DataRow In dt.Rows
            'mendapatkan waktu sekarang
            Dim now As DateTime = DateTime.Now
            'query untuk mengambil waktu update terakhir dari tabel status
            Dim selectWaktu As String = "SELECT waktu_update FROM tbl_status WHERE id_ekspedisi = '" & row("id_ekspedisi") & "' ORDER BY waktu_update DESC LIMIT 1"
            cmd = New MySqlCommand(selectWaktu, con)
            Dim waktu_update As DateTime = cmd.ExecuteScalar()
            'jika waktu sekarang dikurangi dengan waktu update terakhir lebih dari 1 menit (60 detik)
            If (now - waktu_update).TotalSeconds > 60 Then
                'query untuk update status pengiriman menjadi "Dikirim" dan menghapus status sebelumnya yang diproses
                Dim updateStatus As String = "UPDATE tbl_ekspedisi SET status_pengiriman = 'Dikirim' WHERE id_ekspedisi = '" & row("id_ekspedisi") & "'"
                cmd = New MySqlCommand(updateStatus, con)
                cmd.ExecuteNonQuery()
                'query untuk update status pengiriman menjadi "Dikirim" pada tabel tbl_status
                Dim updateStatusTbl As String = "UPDATE tbl_status SET status = 'Dikirim', waktu_update = NOW() WHERE id_ekspedisi = '" & row("id_ekspedisi") & "'"
                cmd = New MySqlCommand(updateStatusTbl, con)
                cmd.ExecuteNonQuery()
                'kemudian kita akan menambahkan timer untuk mengubah status pengiriman menjadi "Diterima" setelah 1 menit dari status "Dikirim"
                Dim timer As New Timer
                timer.Interval = 60000 '1 menit dalam milisecond
                timer.Tag = row("id_ekspedisi")
                AddHandler timer.Tick, AddressOf diterima
                timer.Start()
                'update status pengiriman menjadi "Dikirim" pada tabel tbl_status
                Dim updateStatusTblEks As String = "UPDATE tbl_status SET status = 'Dikirim' WHERE id_ekspedisi = '" & row("id_ekspedisi") & "' AND status = 'Proses'"
                cmd = New MySqlCommand(updateStatusTblEks, con)
                cmd.ExecuteNonQuery()
            End If
        Next
        'mengambil data ekspedisi yang statusnya "Dikirim" atau "Diterima"
        Dim selectEkspedisi2 As String = "SELECT e.id_ekspedisi AS 'ID', u.name AS 'Admin', e.nama_pengirim AS 'Nama Pengirim', e.email_pengirim AS 'Email Pengirim', e.no_pengirim AS 'No Pengirim', e.alamat_pengirim AS 'Alamat Pengirim', e.nama_penerima AS 'Nama Penerima', e.email_penerima AS 'Email Penerima', e.no_penerima AS 'No Penerima', e.alamat_penerima AS 'Alamat Penerima', e.nama_barang AS 'Nama Barang', e.berat_barang AS 'Berat Barang', e.layanan_antar AS 'Layanan Antar', e.biaya_ekspedisi AS 'Biaya Ekspedisi', e.status_pengiriman AS 'Status Pengiriman', e.waktu_input AS 'Waktu Input' FROM tbl_ekspedisi e JOIN tbl_admin u ON e.user_id = u.user_id WHERE e.user_id = '" & id_user & "' AND e.status_pengiriman IN ('Proses','Dikirim', 'Diterima') ORDER BY id_ekspedisi DESC"
        cmd = New MySqlCommand(selectEkspedisi2, con)
        Dim dt2 As New DataTable
        da = New MySqlDataAdapter(cmd)
        da.Fill(dt2)
        'menampilkan data ekspedisi yang statusnya "Dikirim" atau "Diterima" ke datagridview
        DataGridView1.DataSource = dt2
        'menambahkan event handler untuk mengupdate datagridview saat status pengiriman berubah
        AddHandler updateTimer.Tick, AddressOf updateDataGridView
    End Sub

    Private Sub updateDataGridView(sender As Object, e As EventArgs)
        Dim getId As String = "SELECT user_id FROM tbl_admin WHERE email = '" & GlobalVariables.email & "'"
        cmd = New MySqlCommand(getId, con)
        Dim id_user As String = cmd.ExecuteScalar()
        'mengambil data ekspedisi yang statusnya "Dikirim" atau "Diterima"
        Dim selectEkspedisi2 As String = "SELECT e.id_ekspedisi AS 'ID', u.name AS 'Admin', e.nama_pengirim AS 'Nama Pengirim', e.email_pengirim AS 'Email Pengirim', e.no_pengirim AS 'No Pengirim', e.alamat_pengirim AS 'Alamat Pengirim', e.nama_penerima AS 'Nama Penerima', e.email_penerima AS 'Email Penerima', e.no_penerima AS 'No Penerima', e.alamat_penerima AS 'Alamat Penerima', e.nama_barang AS 'Nama Barang', e.berat_barang AS 'Berat Barang', e.layanan_antar AS 'Layanan Antar', e.biaya_ekspedisi AS 'Biaya Ekspedisi', e.status_pengiriman AS 'Status Pengiriman', e.waktu_input AS 'Waktu Input' FROM tbl_ekspedisi e JOIN tbl_admin u ON e.user_id = u.user_id WHERE e.user_id = '" & id_user & "' AND e.status_pengiriman In ('Proses','Dikirim', 'Diterima') ORDER BY id_ekspedisi DESC"
        cmd = New MySqlCommand(selectEkspedisi2, con)
        Dim dt2 As New DataTable
        da = New MySqlDataAdapter(cmd)
        da.Fill(dt2)
        'menampilkan data ekspedisi yang statusnya "Dikirim" atau "Diterima" ke datagridview
        DataGridView1.DataSource = dt2
    End Sub

    Private Sub diterima(sender As Object, e As EventArgs)
        'mendapatkan id ekspedisi dari sender
        Dim id_ekspedisi As String = CType(sender, Timer).Tag
        'query untuk update status pengiriman menjadi "Diterima"
        Dim updateStatus As String = "UPDATE tbl_ekspedisi SET status_pengiriman = 'Diterima' WHERE id_ekspedisi = '" & id_ekspedisi & "'"
        cmd = New MySqlCommand(updateStatus, con)
        cmd.ExecuteNonQuery()

        'query untuk update status pengiriman menjadi "Diterima" pada tabel tbl_status
        Dim updateStatusTbl As String = "UPDATE tbl_status SET status = 'Diterima' WHERE id_ekspedisi = '" & id_ekspedisi & "' AND status = 'Dikirim'"
        cmd = New MySqlCommand(updateStatusTbl, con)
        cmd.ExecuteNonQuery()

        'stop timer setelah status pengiriman berubah menjadi "Diterima"
        Dim timer As Timer = CType(sender, Timer)
        timer.Stop()
        timer.Dispose()

        'menjalankan updateDataGridView untuk mengupdate datagridview saat status pengiriman berubah menjadi "Diterima"
        updateDataGridView(Me, EventArgs.Empty)
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class